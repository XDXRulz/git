create temporary table pgdump_restore_path(p text);
--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
-- Edit the following to match the path where the
-- tar archive has been extracted.
--
insert into pgdump_restore_path values('/tmp');

--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.sfw_users DROP CONSTRAINT sfw_users_status_fk;
ALTER TABLE ONLY public.sfw_users DROP CONSTRAINT sfw_users_role_fk;
ALTER TABLE ONLY public.sfw_users_history DROP CONSTRAINT sfw_users_history_status_fk;
ALTER TABLE ONLY public.sfw_users_history DROP CONSTRAINT sfw_users_history_role_fk;
ALTER TABLE ONLY public.sfw_users_history DROP CONSTRAINT sfw_users_history_rios_fk;
ALTER TABLE ONLY public.sfw_users_history DROP CONSTRAINT sfw_users_history_basin_fk;
ALTER TABLE ONLY public.sfw_users_history DROP CONSTRAINT sfw_users_history_admin_fk;
ALTER TABLE ONLY public.sfw_users_history DROP CONSTRAINT sfw_users_history_action_fk;
ALTER TABLE ONLY public.sfw_user_role_access DROP CONSTRAINT sfw_user_role_access_fk2;
ALTER TABLE ONLY public.sfw_user_role_access DROP CONSTRAINT sfw_user_role_access_fk1;
ALTER TABLE ONLY public.sfw_user_access_history DROP CONSTRAINT sfw_user_access_history_fk2;
ALTER TABLE ONLY public.sfw_user_access_history DROP CONSTRAINT sfw_user_access_history_fk1;
ALTER TABLE ONLY public.sfw_user_access DROP CONSTRAINT sfw_user_access_fk2;
ALTER TABLE ONLY public.sfw_user_access DROP CONSTRAINT sfw_user_access_fk1;
ALTER TABLE ONLY public.sfw_metadata DROP CONSTRAINT sfw_metadata_type_fk;
ALTER TABLE ONLY public.sfw_metadata DROP CONSTRAINT sfw_metadata_theme_fk;
ALTER TABLE ONLY public.sfw_metadata DROP CONSTRAINT sfw_metadata_lang_fk;
ALTER TABLE ONLY public.sfw_metadata_categories DROP CONSTRAINT sfw_metadata_categories_fk;
ALTER TABLE ONLY public.sfw_meta_topics DROP CONSTRAINT sfw_meta_topics_fk2;
ALTER TABLE ONLY public.sfw_meta_topics DROP CONSTRAINT sfw_meta_topics_fk1;
ALTER TABLE ONLY public.sfw_meta_temporal DROP CONSTRAINT sfw_meta_temporal_fk;
ALTER TABLE ONLY public.sfw_meta_responsible DROP CONSTRAINT sfw_meta_responsible_fk2;
ALTER TABLE ONLY public.sfw_meta_responsible DROP CONSTRAINT sfw_meta_responsible_fk1;
ALTER TABLE ONLY public.sfw_meta_responsible_emails DROP CONSTRAINT sfw_meta_responsible_emails_fk;
ALTER TABLE ONLY public.sfw_meta_resolution DROP CONSTRAINT sfw_meta_resolution_fk;
ALTER TABLE ONLY public.sfw_meta_res_langs DROP CONSTRAINT sfw_meta_res_langs_fk2;
ALTER TABLE ONLY public.sfw_meta_res_langs DROP CONSTRAINT sfw_meta_res_langs_fk1;
ALTER TABLE ONLY public.sfw_meta_res_ids DROP CONSTRAINT sfw_meta_res_ids_fk;
ALTER TABLE ONLY public.sfw_meta_public DROP CONSTRAINT sfw_meta_public_fk1;
ALTER TABLE ONLY public.sfw_meta_linkage DROP CONSTRAINT sfw_meta_linkage_fk;
ALTER TABLE ONLY public.sfw_meta_geographic DROP CONSTRAINT sfw_meta_geographic_fk2;
ALTER TABLE ONLY public.sfw_meta_geographic DROP CONSTRAINT sfw_meta_geographic_fk1;
ALTER TABLE ONLY public.sfw_meta_free_keywords DROP CONSTRAINT sfw_meta_free_keywords_fk2;
ALTER TABLE ONLY public.sfw_meta_free_keywords DROP CONSTRAINT sfw_meta_free_keywords_fk1;
ALTER TABLE ONLY public.sfw_meta_coupled_resources DROP CONSTRAINT sfw_meta_coupled_resources_fk;
ALTER TABLE ONLY public.sfw_meta_coupled DROP CONSTRAINT sfw_meta_coupled_fk2;
ALTER TABLE ONLY public.sfw_meta_coupled DROP CONSTRAINT sfw_meta_coupled_fk1;
ALTER TABLE ONLY public.sfw_meta_contacts DROP CONSTRAINT sfw_meta_contacts_fk;
ALTER TABLE ONLY public.sfw_meta_contact_emails DROP CONSTRAINT sfw_meta_contact_emails_fk;
ALTER TABLE ONLY public.sfw_meta_conformity DROP CONSTRAINT sfw_meta_conformity_fk4;
ALTER TABLE ONLY public.sfw_meta_conformity DROP CONSTRAINT sfw_meta_conformity_fk3;
ALTER TABLE ONLY public.sfw_meta_conformity DROP CONSTRAINT sfw_meta_conformity_fk2;
ALTER TABLE ONLY public.sfw_meta_conformity DROP CONSTRAINT sfw_meta_conformity_fk1;
ALTER TABLE ONLY public.sfw_meta_conditions DROP CONSTRAINT sfw_meta_conditions_fk1;
DROP INDEX public.sfw_users_status_fk;
DROP INDEX public.sfw_users_role_fk;
DROP INDEX public.sfw_users_rios_fk;
DROP INDEX public.sfw_users_history_status_fk;
DROP INDEX public.sfw_users_history_role_fk;
DROP INDEX public.sfw_users_history_rios_fk;
DROP INDEX public.sfw_users_history_idx;
DROP INDEX public.sfw_users_history_basin_fk;
DROP INDEX public.sfw_users_history_admin_fk;
DROP INDEX public.sfw_users_history_action_fk;
DROP INDEX public.sfw_users_basin_fk;
DROP INDEX public.sfw_user_role_access_fk2;
DROP INDEX public.sfw_user_role_access_fk1;
DROP INDEX public.sfw_user_access_history_idx;
DROP INDEX public.sfw_user_access_history_fk2;
DROP INDEX public.sfw_user_access_history_fk1;
DROP INDEX public.sfw_user_access_fk2;
DROP INDEX public.sfw_user_access_fk1;
DROP INDEX public.sfw_metadata_type_fk;
DROP INDEX public.sfw_metadata_theme_fk;
DROP INDEX public.sfw_metadata_lang_fk;
DROP INDEX public.sfw_metadata_categories_fk;
DROP INDEX public.sfw_meta_temporal_fk;
DROP INDEX public.sfw_meta_responsible_fk2;
DROP INDEX public.sfw_meta_responsible_fk1;
DROP INDEX public.sfw_meta_responsible_emails_fk;
DROP INDEX public.sfw_meta_resolution_fk;
DROP INDEX public.sfw_meta_res_langs_fk2;
DROP INDEX public.sfw_meta_res_langs_fk1;
DROP INDEX public.sfw_meta_res_ids_fk;
DROP INDEX public.sfw_meta_public_fk1;
DROP INDEX public.sfw_meta_linkage_fk;
DROP INDEX public.sfw_meta_free_keywords_fk2;
DROP INDEX public.sfw_meta_free_keywords_fk1;
DROP INDEX public.sfw_meta_coupled_fk2;
DROP INDEX public.sfw_meta_coupled_fk1;
DROP INDEX public.sfw_meta_contacts_fk;
DROP INDEX public.sfw_meta_contact_emails_fk;
DROP INDEX public.sfw_meta_conformity_fk4;
DROP INDEX public.sfw_meta_conformity_fk3;
DROP INDEX public.sfw_meta_conformity_fk2;
DROP INDEX public.sfw_meta_conformity_fk1;
DROP INDEX public.sfw_meta_conditions_fk1;
ALTER TABLE ONLY public.sfw_action_types DROP CONSTRAINT sw_action_types_pk;
ALTER TABLE ONLY public.sfw_users DROP CONSTRAINT sfw_users_pk;
ALTER TABLE ONLY public.sfw_user_status DROP CONSTRAINT sfw_user_status_pk;
ALTER TABLE ONLY public.sfw_user_roles DROP CONSTRAINT sfw_user_roles_pk;
ALTER TABLE ONLY public.sfw_user_role_access DROP CONSTRAINT sfw_user_role_access_pk;
ALTER TABLE ONLY public.sfw_user_access DROP CONSTRAINT sfw_user_access_pk;
ALTER TABLE ONLY public.sfw_metadata_types DROP CONSTRAINT sfw_metadata_types_pk;
ALTER TABLE ONLY public.sfw_metadata_specifications DROP CONSTRAINT sfw_metadata_specifications_pk;
ALTER TABLE ONLY public.sfw_metadata_roles DROP CONSTRAINT sfw_metadata_roles_pk;
ALTER TABLE ONLY public.sfw_metadata_public DROP CONSTRAINT sfw_metadata_public_pk;
ALTER TABLE ONLY public.sfw_metadata DROP CONSTRAINT sfw_metadata_pk;
ALTER TABLE ONLY public.sfw_metadata_degrees DROP CONSTRAINT sfw_metadata_degrees_pk;
ALTER TABLE ONLY public.sfw_metadata_date_types DROP CONSTRAINT sfw_metadata_date_types_pk;
ALTER TABLE ONLY public.sfw_metadata_countries DROP CONSTRAINT sfw_metadata_countries_pk;
ALTER TABLE ONLY public.sfw_metadata_conditions DROP CONSTRAINT sfw_metadata_conditions_pk;
ALTER TABLE ONLY public.sfw_metadata_categories DROP CONSTRAINT sfw_metadata_categories_pk;
ALTER TABLE ONLY public.sfw_meta_topics DROP CONSTRAINT sfw_meta_topics_pk;
ALTER TABLE ONLY public.sfw_meta_temporal DROP CONSTRAINT sfw_meta_temporal_pk;
ALTER TABLE ONLY public.sfw_meta_responsible DROP CONSTRAINT sfw_meta_responsible_pk;
ALTER TABLE ONLY public.sfw_meta_responsible_emails DROP CONSTRAINT sfw_meta_responsible_emails_pk;
ALTER TABLE ONLY public.sfw_meta_resolution DROP CONSTRAINT sfw_meta_resolution_pk;
ALTER TABLE ONLY public.sfw_meta_res_langs DROP CONSTRAINT sfw_meta_res_langs_pk;
ALTER TABLE ONLY public.sfw_meta_res_ids DROP CONSTRAINT sfw_meta_res_ids_pk;
ALTER TABLE ONLY public.sfw_meta_public DROP CONSTRAINT sfw_meta_public_pk;
ALTER TABLE ONLY public.sfw_meta_linkage DROP CONSTRAINT sfw_meta_linkage_pk;
ALTER TABLE ONLY public.sfw_meta_geographic DROP CONSTRAINT sfw_meta_geographic_pk;
ALTER TABLE ONLY public.sfw_meta_free_keywords DROP CONSTRAINT sfw_meta_free_keywords_pk;
ALTER TABLE ONLY public.sfw_meta_coupled DROP CONSTRAINT sfw_meta_coupled_pk;
ALTER TABLE ONLY public.sfw_meta_contacts DROP CONSTRAINT sfw_meta_contacts_pk;
ALTER TABLE ONLY public.sfw_meta_contact_emails DROP CONSTRAINT sfw_meta_contact_emails_pk;
ALTER TABLE ONLY public.sfw_meta_conformity DROP CONSTRAINT sfw_meta_conformity_pk;
ALTER TABLE ONLY public.sfw_meta_conditions DROP CONSTRAINT sfw_meta_conditions_pk;
ALTER TABLE ONLY public.sfw_access_types DROP CONSTRAINT sfw_access_types_pk;
DROP SEQUENCE public.sfw_users_seq;
DROP TABLE public.sfw_users_history;
DROP TABLE public.sfw_users;
DROP TABLE public.sfw_user_status;
DROP TABLE public.sfw_user_roles;
DROP TABLE public.sfw_user_role_access;
DROP TABLE public.sfw_user_access_history;
DROP TABLE public.sfw_user_access;
DROP TABLE public.sfw_metadata_types;
DROP TABLE public.sfw_metadata_specifications;
DROP TABLE public.sfw_metadata_roles;
DROP TABLE public.sfw_metadata_public;
DROP TABLE public.sfw_metadata_degrees;
DROP TABLE public.sfw_metadata_date_types;
DROP TABLE public.sfw_metadata_countries;
DROP TABLE public.sfw_metadata_conditions;
DROP TABLE public.sfw_metadata_categories;
DROP TABLE public.sfw_metadata;
DROP TABLE public.sfw_meta_topics;
DROP TABLE public.sfw_meta_temporal;
DROP TABLE public.sfw_meta_responsible_emails;
DROP TABLE public.sfw_meta_responsible;
DROP TABLE public.sfw_meta_resolution;
DROP TABLE public.sfw_meta_res_langs;
DROP TABLE public.sfw_meta_res_ids;
DROP TABLE public.sfw_meta_public;
DROP TABLE public.sfw_meta_linkage;
DROP TABLE public.sfw_meta_geographic;
DROP TABLE public.sfw_meta_free_keywords;
DROP TABLE public.sfw_meta_coupled_resources;
DROP TABLE public.sfw_meta_coupled;
DROP TABLE public.sfw_meta_contacts;
DROP TABLE public.sfw_meta_contact_emails;
DROP TABLE public.sfw_meta_conformity;
DROP TABLE public.sfw_meta_conditions;
DROP TABLE public.sfw_action_types;
DROP TABLE public.sfw_access_types;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: sfw_access_types; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_access_types (
    access_id smallint NOT NULL,
    access_rank smallint,
    access_name_bg character varying(64),
    access_name_en character varying(64)
);


ALTER TABLE public.sfw_access_types OWNER TO postgres;

--
-- Name: sfw_action_types; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_action_types (
    action_tp character(1) NOT NULL,
    action_name_bg character varying(16),
    action_name_en character varying(16)
);


ALTER TABLE public.sfw_action_types OWNER TO postgres;

--
-- Name: sfw_meta_conditions; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_meta_conditions (
    resource_id integer NOT NULL,
    condition_num smallint NOT NULL,
    condition_name character varying(500)
);


ALTER TABLE public.sfw_meta_conditions OWNER TO postgres;

--
-- Name: sfw_meta_conformity; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_meta_conformity (
    resource_id integer NOT NULL,
    conformity_num smallint NOT NULL,
    specification_id smallint,
    specification_name character varying(500),
    conformity_date date,
    date_type smallint,
    degree_code smallint
);


ALTER TABLE public.sfw_meta_conformity OWNER TO postgres;

--
-- Name: sfw_meta_contact_emails; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_meta_contact_emails (
    resource_id integer NOT NULL,
    contact_num smallint NOT NULL,
    email_num smallint NOT NULL,
    email character varying(200) NOT NULL
);


ALTER TABLE public.sfw_meta_contact_emails OWNER TO postgres;

--
-- Name: sfw_meta_contacts; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_meta_contacts (
    resource_id integer NOT NULL,
    contact_num smallint NOT NULL,
    organization_name character varying(200) NOT NULL
);


ALTER TABLE public.sfw_meta_contacts OWNER TO postgres;

--
-- Name: sfw_meta_coupled; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_meta_coupled (
    resource1_id integer NOT NULL,
    resource2_id integer NOT NULL
);


ALTER TABLE public.sfw_meta_coupled OWNER TO postgres;

--
-- Name: sfw_meta_coupled_resources; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_meta_coupled_resources (
    coupled_id integer,
    resource_id integer,
    coupled_resource character varying(500)
);


ALTER TABLE public.sfw_meta_coupled_resources OWNER TO postgres;

--
-- Name: sfw_meta_free_keywords; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_meta_free_keywords (
    resource_id integer NOT NULL,
    keyword_num integer NOT NULL,
    keyword_value character varying(200),
    vocabulary_title character varying(200),
    reference_date date,
    date_type smallint
);


ALTER TABLE public.sfw_meta_free_keywords OWNER TO postgres;

--
-- Name: sfw_meta_geographic; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_meta_geographic (
    resource_id integer NOT NULL,
    geographic_num smallint NOT NULL,
    country_code2 character(2),
    s double precision,
    n double precision,
    e double precision,
    w double precision
);


ALTER TABLE public.sfw_meta_geographic OWNER TO postgres;

--
-- Name: sfw_meta_linkage; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_meta_linkage (
    resource_id integer NOT NULL,
    link_num smallint NOT NULL,
    linkage character varying(200) NOT NULL
);


ALTER TABLE public.sfw_meta_linkage OWNER TO postgres;

--
-- Name: sfw_meta_public; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_meta_public (
    resource_id integer NOT NULL,
    public_num smallint NOT NULL,
    public_name character varying(500)
);


ALTER TABLE public.sfw_meta_public OWNER TO postgres;

--
-- Name: sfw_meta_res_ids; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_meta_res_ids (
    resource_id integer NOT NULL,
    id_num smallint NOT NULL,
    id_code character varying(200) NOT NULL,
    id_codespace character varying(200)
);


ALTER TABLE public.sfw_meta_res_ids OWNER TO postgres;

--
-- Name: sfw_meta_res_langs; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_meta_res_langs (
    resource_id integer NOT NULL,
    lang_code2 character(2) NOT NULL
);


ALTER TABLE public.sfw_meta_res_langs OWNER TO postgres;

--
-- Name: sfw_meta_resolution; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_meta_resolution (
    resource_id integer NOT NULL,
    resolution_num smallint NOT NULL,
    equivalent_scale integer,
    distance integer,
    units character varying(32)
);


ALTER TABLE public.sfw_meta_resolution OWNER TO postgres;

--
-- Name: sfw_meta_responsible; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_meta_responsible (
    resource_id integer NOT NULL,
    party_num smallint NOT NULL,
    role_code smallint,
    organization_name character varying(200)
);


ALTER TABLE public.sfw_meta_responsible OWNER TO postgres;

--
-- Name: sfw_meta_responsible_emails; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_meta_responsible_emails (
    resource_id integer NOT NULL,
    party_num smallint NOT NULL,
    email_num smallint NOT NULL,
    email character varying(200)
);


ALTER TABLE public.sfw_meta_responsible_emails OWNER TO postgres;

--
-- Name: sfw_meta_temporal; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_meta_temporal (
    resource_id integer NOT NULL,
    extend_num integer NOT NULL,
    starting_date date,
    ending_date date
);


ALTER TABLE public.sfw_meta_temporal OWNER TO postgres;

--
-- Name: sfw_meta_topics; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_meta_topics (
    resource_id integer NOT NULL,
    category_id integer NOT NULL
);


ALTER TABLE public.sfw_meta_topics OWNER TO postgres;

--
-- Name: sfw_metadata; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_metadata (
    resource_id integer NOT NULL,
    metadata_type smallint,
    meta_date date,
    meta_lang_code character(2) NOT NULL,
    resource_title character varying(200) NOT NULL,
    resource_abstract character varying(2000) NOT NULL,
    create_date date,
    publication_date date,
    last_revision_date date,
    lineage character varying(2000),
    inspire_theme_id smallint
);


ALTER TABLE public.sfw_metadata OWNER TO postgres;

--
-- Name: sfw_metadata_categories; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_metadata_categories (
    metadata_type smallint NOT NULL,
    category_code integer NOT NULL,
    category_name_bg character varying(200),
    category_name_en character varying(200),
    inspire_code character varying(100)
);


ALTER TABLE public.sfw_metadata_categories OWNER TO postgres;

--
-- Name: sfw_metadata_conditions; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_metadata_conditions (
    condition_id smallint NOT NULL,
    condition_name character varying(575)
);


ALTER TABLE public.sfw_metadata_conditions OWNER TO postgres;

--
-- Name: sfw_metadata_countries; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_metadata_countries (
    country_code2 character(2) NOT NULL,
    country_code3 character(3),
    country_name_bg character varying(64),
    country_name_en character varying(64),
    lang_name_bg character varying(32),
    lang_name_en character varying(32),
    s double precision,
    w double precision,
    n double precision,
    e double precision
);


ALTER TABLE public.sfw_metadata_countries OWNER TO postgres;

--
-- Name: sfw_metadata_date_types; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_metadata_date_types (
    date_type smallint NOT NULL,
    date_name character varying(64),
    date_code character varying(32)
);


ALTER TABLE public.sfw_metadata_date_types OWNER TO postgres;

--
-- Name: sfw_metadata_degrees; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_metadata_degrees (
    degree_code smallint NOT NULL,
    degree_name_bg character varying(32),
    degree_name_en character varying(32)
);


ALTER TABLE public.sfw_metadata_degrees OWNER TO postgres;

--
-- Name: sfw_metadata_public; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_metadata_public (
    public_id smallint NOT NULL,
    public_name character varying(500)
);


ALTER TABLE public.sfw_metadata_public OWNER TO postgres;

--
-- Name: sfw_metadata_roles; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_metadata_roles (
    role_code smallint NOT NULL,
    role_name_bg character varying(64),
    role_name_en character varying(64)
);


ALTER TABLE public.sfw_metadata_roles OWNER TO postgres;

--
-- Name: sfw_metadata_specifications; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_metadata_specifications (
    specification_id smallint NOT NULL,
    specification_name_bg character varying(200),
    specification_name_en character varying(200)
);


ALTER TABLE public.sfw_metadata_specifications OWNER TO postgres;

--
-- Name: sfw_metadata_types; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_metadata_types (
    metadata_type smallint NOT NULL,
    metadata_type_bg character varying(64),
    metadata_type_en character varying(64),
    metadata_type_code character varying(100)
);


ALTER TABLE public.sfw_metadata_types OWNER TO postgres;

--
-- Name: sfw_user_access; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_user_access (
    user_id integer NOT NULL,
    access_id smallint NOT NULL
);


ALTER TABLE public.sfw_user_access OWNER TO postgres;

--
-- Name: sfw_user_access_history; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_user_access_history (
    user_id integer NOT NULL,
    access_id smallint NOT NULL,
    admin_dt date NOT NULL,
    admin_id integer NOT NULL,
    action_tp character(1) NOT NULL
);


ALTER TABLE public.sfw_user_access_history OWNER TO postgres;

--
-- Name: sfw_user_role_access; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_user_role_access (
    role_id smallint NOT NULL,
    access_id smallint NOT NULL
);


ALTER TABLE public.sfw_user_role_access OWNER TO postgres;

--
-- Name: sfw_user_roles; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_user_roles (
    role_id smallint NOT NULL,
    role_rank smallint,
    role_name_bg character varying(64),
    role_name_en character varying(64)
);


ALTER TABLE public.sfw_user_roles OWNER TO postgres;

--
-- Name: sfw_user_status; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_user_status (
    status smallint NOT NULL,
    status_name_bg character varying(16),
    status_name_en character varying(16)
);


ALTER TABLE public.sfw_user_status OWNER TO postgres;

--
-- Name: sfw_users; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_users (
    user_id integer NOT NULL,
    login_name character varying(32) NOT NULL,
    login_pass character varying(32) NOT NULL,
    is_temporary character(1),
    user_name character varying(64) NOT NULL,
    user_position character varying(32),
    role_id smallint NOT NULL,
    rios_code character(2),
    basein_code character(1),
    lab_id integer,
    status smallint NOT NULL,
    last_login date,
    CONSTRAINT sfw_users_is_temporary_check CHECK ((is_temporary = ANY (ARRAY['N'::bpchar, 'Y'::bpchar])))
);


ALTER TABLE public.sfw_users OWNER TO postgres;

--
-- Name: sfw_users_history; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE sfw_users_history (
    user_id integer NOT NULL,
    login_name character varying(32),
    login_pass character varying(32),
    is_temporary character(1),
    user_name character varying(64),
    user_position character varying(32),
    role_id smallint,
    rios_code character(2),
    basein_code character(1),
    lab_id integer,
    status smallint,
    last_login date,
    admin_dt date NOT NULL,
    admin_id integer NOT NULL,
    action_tp character(1) NOT NULL
);


ALTER TABLE public.sfw_users_history OWNER TO postgres;

--
-- Name: sfw_users_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE sfw_users_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 99999
    CACHE 1;


ALTER TABLE public.sfw_users_seq OWNER TO postgres;

--
-- Name: sfw_users_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('sfw_users_seq', 1, false);


--
-- Data for Name: sfw_access_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_action_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_meta_conditions; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_meta_conformity; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_meta_contact_emails; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_meta_contacts; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_meta_coupled; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_meta_coupled_resources; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_meta_free_keywords; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_meta_geographic; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_meta_linkage; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_meta_public; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_meta_res_ids; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_meta_res_langs; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_meta_resolution; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_meta_responsible; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_meta_responsible_emails; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_meta_temporal; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_meta_topics; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_metadata; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_metadata_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_metadata_conditions; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_metadata_countries; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_metadata_date_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_metadata_degrees; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_metadata_public; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_metadata_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_metadata_specifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_metadata_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_user_access; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_user_access_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_user_role_access; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_user_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_user_status; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Data for Name: sfw_users_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

--
-- Name: sfw_access_types_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_access_types
    ADD CONSTRAINT sfw_access_types_pk PRIMARY KEY (access_id);


--
-- Name: sfw_meta_conditions_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_meta_conditions
    ADD CONSTRAINT sfw_meta_conditions_pk PRIMARY KEY (resource_id, condition_num);


--
-- Name: sfw_meta_conformity_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_meta_conformity
    ADD CONSTRAINT sfw_meta_conformity_pk PRIMARY KEY (resource_id, conformity_num);


--
-- Name: sfw_meta_contact_emails_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_meta_contact_emails
    ADD CONSTRAINT sfw_meta_contact_emails_pk PRIMARY KEY (resource_id, contact_num, email_num);


--
-- Name: sfw_meta_contacts_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_meta_contacts
    ADD CONSTRAINT sfw_meta_contacts_pk PRIMARY KEY (resource_id, contact_num);


--
-- Name: sfw_meta_coupled_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_meta_coupled
    ADD CONSTRAINT sfw_meta_coupled_pk PRIMARY KEY (resource1_id, resource2_id);


--
-- Name: sfw_meta_free_keywords_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_meta_free_keywords
    ADD CONSTRAINT sfw_meta_free_keywords_pk PRIMARY KEY (resource_id, keyword_num);


--
-- Name: sfw_meta_geographic_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_meta_geographic
    ADD CONSTRAINT sfw_meta_geographic_pk PRIMARY KEY (resource_id, geographic_num);


--
-- Name: sfw_meta_linkage_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_meta_linkage
    ADD CONSTRAINT sfw_meta_linkage_pk PRIMARY KEY (resource_id, link_num);


--
-- Name: sfw_meta_public_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_meta_public
    ADD CONSTRAINT sfw_meta_public_pk PRIMARY KEY (resource_id, public_num);


--
-- Name: sfw_meta_res_ids_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_meta_res_ids
    ADD CONSTRAINT sfw_meta_res_ids_pk PRIMARY KEY (resource_id, id_num);


--
-- Name: sfw_meta_res_langs_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_meta_res_langs
    ADD CONSTRAINT sfw_meta_res_langs_pk PRIMARY KEY (resource_id, lang_code2);


--
-- Name: sfw_meta_resolution_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_meta_resolution
    ADD CONSTRAINT sfw_meta_resolution_pk PRIMARY KEY (resource_id, resolution_num);


--
-- Name: sfw_meta_responsible_emails_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_meta_responsible_emails
    ADD CONSTRAINT sfw_meta_responsible_emails_pk PRIMARY KEY (resource_id, party_num, email_num);


--
-- Name: sfw_meta_responsible_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_meta_responsible
    ADD CONSTRAINT sfw_meta_responsible_pk PRIMARY KEY (resource_id, party_num);


--
-- Name: sfw_meta_temporal_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_meta_temporal
    ADD CONSTRAINT sfw_meta_temporal_pk PRIMARY KEY (resource_id, extend_num);


--
-- Name: sfw_meta_topics_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_meta_topics
    ADD CONSTRAINT sfw_meta_topics_pk PRIMARY KEY (resource_id, category_id);


--
-- Name: sfw_metadata_categories_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_metadata_categories
    ADD CONSTRAINT sfw_metadata_categories_pk PRIMARY KEY (category_code);


--
-- Name: sfw_metadata_conditions_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_metadata_conditions
    ADD CONSTRAINT sfw_metadata_conditions_pk PRIMARY KEY (condition_id);


--
-- Name: sfw_metadata_countries_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_metadata_countries
    ADD CONSTRAINT sfw_metadata_countries_pk PRIMARY KEY (country_code2);


--
-- Name: sfw_metadata_date_types_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_metadata_date_types
    ADD CONSTRAINT sfw_metadata_date_types_pk PRIMARY KEY (date_type);


--
-- Name: sfw_metadata_degrees_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_metadata_degrees
    ADD CONSTRAINT sfw_metadata_degrees_pk PRIMARY KEY (degree_code);


--
-- Name: sfw_metadata_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_metadata
    ADD CONSTRAINT sfw_metadata_pk PRIMARY KEY (resource_id);


--
-- Name: sfw_metadata_public_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_metadata_public
    ADD CONSTRAINT sfw_metadata_public_pk PRIMARY KEY (public_id);


--
-- Name: sfw_metadata_roles_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_metadata_roles
    ADD CONSTRAINT sfw_metadata_roles_pk PRIMARY KEY (role_code);


--
-- Name: sfw_metadata_specifications_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_metadata_specifications
    ADD CONSTRAINT sfw_metadata_specifications_pk PRIMARY KEY (specification_id);


--
-- Name: sfw_metadata_types_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_metadata_types
    ADD CONSTRAINT sfw_metadata_types_pk PRIMARY KEY (metadata_type);


--
-- Name: sfw_user_access_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_user_access
    ADD CONSTRAINT sfw_user_access_pk PRIMARY KEY (user_id, access_id);


--
-- Name: sfw_user_role_access_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_user_role_access
    ADD CONSTRAINT sfw_user_role_access_pk PRIMARY KEY (role_id, access_id);


--
-- Name: sfw_user_roles_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_user_roles
    ADD CONSTRAINT sfw_user_roles_pk PRIMARY KEY (role_id);


--
-- Name: sfw_user_status_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_user_status
    ADD CONSTRAINT sfw_user_status_pk PRIMARY KEY (status);


--
-- Name: sfw_users_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_users
    ADD CONSTRAINT sfw_users_pk PRIMARY KEY (user_id);


--
-- Name: sw_action_types_pk; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sfw_action_types
    ADD CONSTRAINT sw_action_types_pk PRIMARY KEY (action_tp);


--
-- Name: sfw_meta_conditions_fk1; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_meta_conditions_fk1 ON sfw_meta_conditions USING btree (resource_id);


--
-- Name: sfw_meta_conformity_fk1; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_meta_conformity_fk1 ON sfw_meta_conformity USING btree (resource_id);


--
-- Name: sfw_meta_conformity_fk2; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_meta_conformity_fk2 ON sfw_meta_conformity USING btree (specification_id);


--
-- Name: sfw_meta_conformity_fk3; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_meta_conformity_fk3 ON sfw_meta_conformity USING btree (date_type);


--
-- Name: sfw_meta_conformity_fk4; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_meta_conformity_fk4 ON sfw_meta_conformity USING btree (degree_code);


--
-- Name: sfw_meta_contact_emails_fk; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_meta_contact_emails_fk ON sfw_meta_contact_emails USING btree (resource_id, contact_num);


--
-- Name: sfw_meta_contacts_fk; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_meta_contacts_fk ON sfw_meta_contacts USING btree (resource_id);


--
-- Name: sfw_meta_coupled_fk1; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_meta_coupled_fk1 ON sfw_meta_coupled USING btree (resource1_id);


--
-- Name: sfw_meta_coupled_fk2; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_meta_coupled_fk2 ON sfw_meta_coupled USING btree (resource2_id);


--
-- Name: sfw_meta_free_keywords_fk1; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_meta_free_keywords_fk1 ON sfw_meta_free_keywords USING btree (resource_id);


--
-- Name: sfw_meta_free_keywords_fk2; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_meta_free_keywords_fk2 ON sfw_meta_free_keywords USING btree (date_type);


--
-- Name: sfw_meta_linkage_fk; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_meta_linkage_fk ON sfw_meta_linkage USING btree (resource_id);


--
-- Name: sfw_meta_public_fk1; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_meta_public_fk1 ON sfw_meta_public USING btree (resource_id);


--
-- Name: sfw_meta_res_ids_fk; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_meta_res_ids_fk ON sfw_meta_res_ids USING btree (resource_id);


--
-- Name: sfw_meta_res_langs_fk1; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_meta_res_langs_fk1 ON sfw_meta_res_langs USING btree (resource_id);


--
-- Name: sfw_meta_res_langs_fk2; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_meta_res_langs_fk2 ON sfw_meta_res_langs USING btree (lang_code2);


--
-- Name: sfw_meta_resolution_fk; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_meta_resolution_fk ON sfw_meta_resolution USING btree (resource_id);


--
-- Name: sfw_meta_responsible_emails_fk; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_meta_responsible_emails_fk ON sfw_meta_responsible_emails USING btree (resource_id, party_num);


--
-- Name: sfw_meta_responsible_fk1; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_meta_responsible_fk1 ON sfw_meta_responsible USING btree (resource_id);


--
-- Name: sfw_meta_responsible_fk2; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_meta_responsible_fk2 ON sfw_meta_responsible USING btree (role_code);


--
-- Name: sfw_meta_temporal_fk; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_meta_temporal_fk ON sfw_meta_temporal USING btree (resource_id);


--
-- Name: sfw_metadata_categories_fk; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_metadata_categories_fk ON sfw_metadata_categories USING btree (metadata_type);


--
-- Name: sfw_metadata_lang_fk; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_metadata_lang_fk ON sfw_metadata USING btree (meta_lang_code);


--
-- Name: sfw_metadata_theme_fk; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_metadata_theme_fk ON sfw_metadata USING btree (inspire_theme_id);


--
-- Name: sfw_metadata_type_fk; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_metadata_type_fk ON sfw_metadata USING btree (metadata_type);


--
-- Name: sfw_user_access_fk1; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_user_access_fk1 ON sfw_user_access USING btree (user_id);


--
-- Name: sfw_user_access_fk2; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_user_access_fk2 ON sfw_user_access USING btree (access_id);


--
-- Name: sfw_user_access_history_fk1; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_user_access_history_fk1 ON sfw_user_access_history USING btree (admin_id);


--
-- Name: sfw_user_access_history_fk2; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_user_access_history_fk2 ON sfw_user_access_history USING btree (action_tp);


--
-- Name: sfw_user_access_history_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_user_access_history_idx ON sfw_user_access_history USING btree (user_id, access_id, admin_dt);


--
-- Name: sfw_user_role_access_fk1; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_user_role_access_fk1 ON sfw_user_role_access USING btree (role_id);


--
-- Name: sfw_user_role_access_fk2; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_user_role_access_fk2 ON sfw_user_role_access USING btree (access_id);


--
-- Name: sfw_users_basin_fk; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_users_basin_fk ON sfw_users USING btree (basein_code);


--
-- Name: sfw_users_history_action_fk; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_users_history_action_fk ON sfw_users_history USING btree (action_tp);


--
-- Name: sfw_users_history_admin_fk; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_users_history_admin_fk ON sfw_users_history USING btree (admin_id);


--
-- Name: sfw_users_history_basin_fk; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_users_history_basin_fk ON sfw_users_history USING btree (basein_code);


--
-- Name: sfw_users_history_idx; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_users_history_idx ON sfw_users_history USING btree (user_id, admin_dt);


--
-- Name: sfw_users_history_rios_fk; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_users_history_rios_fk ON sfw_users_history USING btree (rios_code);


--
-- Name: sfw_users_history_role_fk; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_users_history_role_fk ON sfw_users_history USING btree (role_id);


--
-- Name: sfw_users_history_status_fk; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_users_history_status_fk ON sfw_users_history USING btree (status);


--
-- Name: sfw_users_rios_fk; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_users_rios_fk ON sfw_users USING btree (rios_code);


--
-- Name: sfw_users_role_fk; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_users_role_fk ON sfw_users USING btree (role_id);


--
-- Name: sfw_users_status_fk; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX sfw_users_status_fk ON sfw_users USING btree (status);


--
-- Name: sfw_meta_conditions_fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_meta_conditions
    ADD CONSTRAINT sfw_meta_conditions_fk1 FOREIGN KEY (resource_id) REFERENCES sfw_metadata(resource_id);


--
-- Name: sfw_meta_conformity_fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_meta_conformity
    ADD CONSTRAINT sfw_meta_conformity_fk1 FOREIGN KEY (resource_id) REFERENCES sfw_metadata(resource_id);


--
-- Name: sfw_meta_conformity_fk2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_meta_conformity
    ADD CONSTRAINT sfw_meta_conformity_fk2 FOREIGN KEY (specification_id) REFERENCES sfw_metadata_specifications(specification_id);


--
-- Name: sfw_meta_conformity_fk3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_meta_conformity
    ADD CONSTRAINT sfw_meta_conformity_fk3 FOREIGN KEY (date_type) REFERENCES sfw_metadata_date_types(date_type);


--
-- Name: sfw_meta_conformity_fk4; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_meta_conformity
    ADD CONSTRAINT sfw_meta_conformity_fk4 FOREIGN KEY (degree_code) REFERENCES sfw_metadata_degrees(degree_code);


--
-- Name: sfw_meta_contact_emails_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_meta_contact_emails
    ADD CONSTRAINT sfw_meta_contact_emails_fk FOREIGN KEY (resource_id, contact_num) REFERENCES sfw_meta_contacts(resource_id, contact_num);


--
-- Name: sfw_meta_contacts_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_meta_contacts
    ADD CONSTRAINT sfw_meta_contacts_fk FOREIGN KEY (resource_id) REFERENCES sfw_metadata(resource_id);


--
-- Name: sfw_meta_coupled_fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_meta_coupled
    ADD CONSTRAINT sfw_meta_coupled_fk1 FOREIGN KEY (resource1_id) REFERENCES sfw_metadata(resource_id);


--
-- Name: sfw_meta_coupled_fk2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_meta_coupled
    ADD CONSTRAINT sfw_meta_coupled_fk2 FOREIGN KEY (resource2_id) REFERENCES sfw_metadata(resource_id);


--
-- Name: sfw_meta_coupled_resources_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_meta_coupled_resources
    ADD CONSTRAINT sfw_meta_coupled_resources_fk FOREIGN KEY (resource_id) REFERENCES sfw_metadata(resource_id);


--
-- Name: sfw_meta_free_keywords_fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_meta_free_keywords
    ADD CONSTRAINT sfw_meta_free_keywords_fk1 FOREIGN KEY (resource_id) REFERENCES sfw_metadata(resource_id);


--
-- Name: sfw_meta_free_keywords_fk2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_meta_free_keywords
    ADD CONSTRAINT sfw_meta_free_keywords_fk2 FOREIGN KEY (date_type) REFERENCES sfw_metadata_date_types(date_type);


--
-- Name: sfw_meta_geographic_fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_meta_geographic
    ADD CONSTRAINT sfw_meta_geographic_fk1 FOREIGN KEY (resource_id) REFERENCES sfw_metadata(resource_id);


--
-- Name: sfw_meta_geographic_fk2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_meta_geographic
    ADD CONSTRAINT sfw_meta_geographic_fk2 FOREIGN KEY (country_code2) REFERENCES sfw_metadata_countries(country_code2);


--
-- Name: sfw_meta_linkage_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_meta_linkage
    ADD CONSTRAINT sfw_meta_linkage_fk FOREIGN KEY (resource_id) REFERENCES sfw_metadata(resource_id);


--
-- Name: sfw_meta_public_fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_meta_public
    ADD CONSTRAINT sfw_meta_public_fk1 FOREIGN KEY (resource_id) REFERENCES sfw_metadata(resource_id);


--
-- Name: sfw_meta_res_ids_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_meta_res_ids
    ADD CONSTRAINT sfw_meta_res_ids_fk FOREIGN KEY (resource_id) REFERENCES sfw_metadata(resource_id);


--
-- Name: sfw_meta_res_langs_fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_meta_res_langs
    ADD CONSTRAINT sfw_meta_res_langs_fk1 FOREIGN KEY (resource_id) REFERENCES sfw_metadata(resource_id);


--
-- Name: sfw_meta_res_langs_fk2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_meta_res_langs
    ADD CONSTRAINT sfw_meta_res_langs_fk2 FOREIGN KEY (lang_code2) REFERENCES sfw_metadata_countries(country_code2);


--
-- Name: sfw_meta_resolution_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_meta_resolution
    ADD CONSTRAINT sfw_meta_resolution_fk FOREIGN KEY (resource_id) REFERENCES sfw_metadata(resource_id);


--
-- Name: sfw_meta_responsible_emails_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_meta_responsible_emails
    ADD CONSTRAINT sfw_meta_responsible_emails_fk FOREIGN KEY (resource_id, party_num) REFERENCES sfw_meta_responsible(resource_id, party_num);


--
-- Name: sfw_meta_responsible_fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_meta_responsible
    ADD CONSTRAINT sfw_meta_responsible_fk1 FOREIGN KEY (resource_id) REFERENCES sfw_metadata(resource_id);


--
-- Name: sfw_meta_responsible_fk2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_meta_responsible
    ADD CONSTRAINT sfw_meta_responsible_fk2 FOREIGN KEY (role_code) REFERENCES sfw_metadata_roles(role_code);


--
-- Name: sfw_meta_temporal_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_meta_temporal
    ADD CONSTRAINT sfw_meta_temporal_fk FOREIGN KEY (resource_id) REFERENCES sfw_metadata(resource_id);


--
-- Name: sfw_meta_topics_fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_meta_topics
    ADD CONSTRAINT sfw_meta_topics_fk1 FOREIGN KEY (resource_id) REFERENCES sfw_metadata(resource_id);


--
-- Name: sfw_meta_topics_fk2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_meta_topics
    ADD CONSTRAINT sfw_meta_topics_fk2 FOREIGN KEY (category_id) REFERENCES sfw_metadata_categories(category_code);


--
-- Name: sfw_metadata_categories_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_metadata_categories
    ADD CONSTRAINT sfw_metadata_categories_fk FOREIGN KEY (metadata_type) REFERENCES sfw_metadata_types(metadata_type);


--
-- Name: sfw_metadata_lang_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_metadata
    ADD CONSTRAINT sfw_metadata_lang_fk FOREIGN KEY (meta_lang_code) REFERENCES sfw_metadata_countries(country_code2);


--
-- Name: sfw_metadata_theme_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_metadata
    ADD CONSTRAINT sfw_metadata_theme_fk FOREIGN KEY (inspire_theme_id) REFERENCES sfw_metadata_specifications(specification_id);


--
-- Name: sfw_metadata_type_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_metadata
    ADD CONSTRAINT sfw_metadata_type_fk FOREIGN KEY (metadata_type) REFERENCES sfw_metadata_types(metadata_type);


--
-- Name: sfw_user_access_fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_user_access
    ADD CONSTRAINT sfw_user_access_fk1 FOREIGN KEY (user_id) REFERENCES sfw_users(user_id) ON DELETE CASCADE;


--
-- Name: sfw_user_access_fk2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_user_access
    ADD CONSTRAINT sfw_user_access_fk2 FOREIGN KEY (access_id) REFERENCES sfw_access_types(access_id) ON DELETE CASCADE;


--
-- Name: sfw_user_access_history_fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_user_access_history
    ADD CONSTRAINT sfw_user_access_history_fk1 FOREIGN KEY (admin_id) REFERENCES sfw_users(user_id);


--
-- Name: sfw_user_access_history_fk2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_user_access_history
    ADD CONSTRAINT sfw_user_access_history_fk2 FOREIGN KEY (action_tp) REFERENCES sfw_action_types(action_tp);


--
-- Name: sfw_user_role_access_fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_user_role_access
    ADD CONSTRAINT sfw_user_role_access_fk1 FOREIGN KEY (role_id) REFERENCES sfw_user_roles(role_id) ON DELETE CASCADE;


--
-- Name: sfw_user_role_access_fk2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_user_role_access
    ADD CONSTRAINT sfw_user_role_access_fk2 FOREIGN KEY (access_id) REFERENCES sfw_access_types(access_id) ON DELETE CASCADE;


--
-- Name: sfw_users_history_action_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_users_history
    ADD CONSTRAINT sfw_users_history_action_fk FOREIGN KEY (action_tp) REFERENCES sfw_action_types(action_tp);


--
-- Name: sfw_users_history_admin_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_users_history
    ADD CONSTRAINT sfw_users_history_admin_fk FOREIGN KEY (admin_id) REFERENCES sfw_users(user_id);


--
-- Name: sfw_users_history_basin_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_users_history
    ADD CONSTRAINT sfw_users_history_basin_fk FOREIGN KEY (status) REFERENCES sfw_user_status(status);


--
-- Name: sfw_users_history_rios_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_users_history
    ADD CONSTRAINT sfw_users_history_rios_fk FOREIGN KEY (role_id) REFERENCES sfw_user_roles(role_id);


--
-- Name: sfw_users_history_role_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_users_history
    ADD CONSTRAINT sfw_users_history_role_fk FOREIGN KEY (role_id) REFERENCES sfw_user_roles(role_id);


--
-- Name: sfw_users_history_status_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_users_history
    ADD CONSTRAINT sfw_users_history_status_fk FOREIGN KEY (status) REFERENCES sfw_user_status(status);


--
-- Name: sfw_users_role_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_users
    ADD CONSTRAINT sfw_users_role_fk FOREIGN KEY (role_id) REFERENCES sfw_user_roles(role_id);


--
-- Name: sfw_users_status_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sfw_users
    ADD CONSTRAINT sfw_users_status_fk FOREIGN KEY (status) REFERENCES sfw_user_status(status);


--
-- PostgreSQL database dump complete
--

